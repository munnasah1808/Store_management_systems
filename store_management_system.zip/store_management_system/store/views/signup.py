from django.shortcuts import render, redirect
from store.forms import CustomerSignUpForm, EmployeeSignUpForm

# Signup view function
def signup_register(request):
      return render(request,'signup_register.html')


# Customer Signup view function
def customer_signup(request):
    if request.method == 'POST':
        form = CustomerSignUpForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('homepage')

    else:
        form = CustomerSignUpForm()
    return render(request,'customer_signup.html',{'form':form} )


# Employee Signup view function
def employee_signup(request):
    if request.method == 'POST':
        form = EmployeeSignUpForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('homepage')

    else:
        form = EmployeeSignUpForm()
    return render(request,'employee_signup.html',{'form':form} )