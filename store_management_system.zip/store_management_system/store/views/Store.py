from django.shortcuts import render, HttpResponseRedirect
from store.models.product import Product
from store.middlewares.auth import auth_middleware



# Products Details view function
def detailsview(request ):
    if request.user.is_authenticated:
        products = Product.objects.all()
        return render(request,'store.html',{'products':products,'name':request.user.username})
    else:
        return HttpResponseRedirect('login')


    
